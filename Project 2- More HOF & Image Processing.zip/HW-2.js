let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel): Image
function imageMapXY(img, pixelFunction){
  let copyImage = img;
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let pixel = pixelFunction(copyImage, i, j);
      copyImage.setPixel(i, j, pixel);
    }
  }
  return copyImage;
}
//Test 1: imageMapXY(robot, function(img, x, y) { return [img.getPixel(x, y)[0], 0, 0];}).show();


//imageMask(img: Image, cond: (img: Image, x: number, y: number) => boolean, maskValue: Pixel): Image
function imageMask(img, cond, maskValue){
  let copyImage = img.copy()
  copyImage = imageMapXY(copyImage, function(img, x, y){ if(cond(img, x, y)){return maskValue}return img.getPixel(x,y)})
  return copyImage;
}
//Test 2: imageMask(robot, function(img,x,y){ return (y % 10 === 0); }, [1, 0, 0]).show();

//imageMapCond(img: Image, cond: (img: Image, x: number, y: number) => boolean, func: (p: Pixel) => Pixel): Image
function imageMapCond(img, cond, func){
  let copyImage = img.copy()
  copyImage = imageMapXY(copyImage, function(img, x, y){ if(cond(img, x, y)){return func(img.getPixel(x,y))}return img.getPixel(x,y)})
  return copyImage;
}

//Test 3: imageMapCond(robot, function(img,x,y){ return (y % 10 === 0); }, function(p){return [0,0,1]}).show();

//isGrayish(p: Pixel): boolean
function isGrayish(p){
  let max = p.reduce((a,b) => Math.max(a,b), p[0]);
  let min = p.reduce((a,b) => Math.min(a,b), p[0]);
  let diff = max-min;
  if(diff <= (1/3)){
    return true;
  }else{
    return false;
  }
}
//Test 4: console.log(isGrayish([1,0.6,1]))

//makeGrayish(img: Image): Image
function makeGrayish(img){
  let copyImage = img.copy();
  copyImage = imageMapXY(copyImage, function(img, x, y){ 
                                      if(!isGrayish(img.getPixel(x,y))){
                                        let p = img.getPixel(x,y);
                                        let avg = (p[0] + p[1] + p[2])/3;
                                        return [avg, avg, avg];
                                      }
                                        return img.getPixel(x,y);
                                    })
  return copyImage;
}
//Test 5: makeGrayish(robot).show()

//grayHalfImage(img: Image): Image
function grayHalfImage(img){
  let copyImage = img.copy();
  copyImage = imageMapXY(copyImage, function(img, x, y){
                                      if(y<img.height/2 && !isGrayish(img.getPixel(x,y))){
                                        let p = img.getPixel(x,y);
                                        let avg = (p[0] + p[1] + p[2])/3;
                                        return [avg, avg, avg];
                                      }
                                        return img.getPixel(x,y);
                                    })
  return copyImage;
}
//Test 6: grayHalfImage(robot).show()

//blackenLow(img: Image): Image
function blackenLow(img){
  let copyImage = img.copy();
  copyImage = imageMapXY(copyImage, function(img, x, y){
                                      let p = img.getPixel(x,y);
                                      if(p[0] < (1/3)){ p[0] = 0; }
                                      if(p[1] < (1/3)){ p[1] = 0; }
                                      if(p[2] < (1/3)){ p[2] = 0; }
                                      return p;
                                    })
  return copyImage;
}
//Test 7: blackenLow(robot).show();