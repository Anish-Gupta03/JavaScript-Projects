// Returns a random int i where min <= i < max
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

//generateInput(n: number): number[][]
function generateInput(n){
  let prefArr = [];
  for(let i = 0; i<n; ++i){
    let arr = []
    for(let j = 0; j<n; ++j){
      let rando = randomInt(0,n);
      while(arr.includes(rando)){
        rando = randomInt(0,n)
      }
      arr.push(rando);
  }
    prefArr.push(arr)
  }
  return prefArr;
}
console.log(generateInput(3));

//runOracle(f: (companies: number[][], candidates: number[][]) => Run): void
function runOracle(f){
  let numTests = 50;
  let n = 10;
  for(let i=0; i<numTests; ++i){
    let companies = generateInput(n);
    let candidates = generateInput(n);
    let run = f(companies, candidates);

    //Test 1: The hires had an offer in offers
    let count = 0;
    for(let j =0; j<run.out.length; ++j){
      let hire = run.out[j];
      if(!run.trace.some(o=> (o.from === hire.company && o.to === hire.candidate) || (o.from === hire.candidate && o.to === hire.company))){
        count +=1;
      }
    }
    test('There was an offer', function(){
      assert(count === 0);
    })
    
    //Test 2: out is the result of the offers in trace
    //for each pairing. go through the offers and make sure that neither the company or candidate got a better offer according to their preference list
    count = 0;
    for(let i =0; i<run.out.length; ++i){
      let curMatch = run.out[i];
      let comp = curMatch.company;
      let cand = curMatch.candidate;
      //make sure curCompany or curCand didnt recieve a better offer. 
      run.trace.some(o=>{
        if(!o.fromCo && (o.to === comp) && (companies[comp].indexOf(o.from) < companies[comp].indexOf(cand)) ){
          count +=1;
          return false;
        }
        else if(o.fromCo && (o.to === cand) && (candidates[cand].indexOf(o.from) < candidates[cand].indexOf(comp)) ){
          count +=1;
          return false;
        }else{
          return true;
        }
      })
      if(count !== 0){ break; }
    }
    test('out is result of offers in trace', function(){
        assert(count === 0);
    })

    //Test 3: Make sure that the algorithim stops when all parties are matched
    let arr = [];
    for(let i =0; i<run.trace.length; ++i){
      let offer = run.trace[i];
      let arrContainsComp = false;
      let indexOfComp = -1;
      let arrContainsCand = false;
      let indexOfCand = -1;
      for(let j =0; j<arr.length; ++j){
        if(offer.fromCo && arr[j].company === offer.from){
          arrContainsComp = true;
          indexOfComp = j;
        }
        if(!offer.fromCo && arr[j].candidate === offer.from){
          arrContainsCand = true;
          indexOfCand = j;
        }
      }
        //check that the current offer is better than the previous offer and that they should be match if it works with candidate. This also checks that the algorithim stops when the parties have proposed to everyone in their preference array
      if(offer.fromCo){
        if(!arrContainsCand && !arrContainsComp){
          arr.push({company: offer.from, candidate: offer.to})
        }
        if(!arrContainsCand && arrContainsComp && companies[offer.from].indexOf(offer.to)<companies[offer.from].indexOf(arr[indexOfComp].candidate)){
          arr[indexOfComp].candidate = offer.to;
        }
        if(arrContainsCand && !arrContainsComp && candidates[offer.to].indexOf(offer.from)<candidates[offer.to].indexOf(arr[indexOfCand].company)){
          arr[indexOfCand].company = offer.from;
        }
      }
      if(!offer.fromCo){
        if(!arrContainsCand && !arrContainsComp){
          arr.push({company: offer.to, candidate: offer.from})
        }
        if(!arrContainsCand && arrContainsComp && companies[offer.from].indexOf(offer.to)<companies[offer.from].indexOf(arr[indexOfComp].candidate)){
          arr[indexOfComp].candidate = offer.from
        }
        if(arrContainsCand && !arrContainsComp && candidates[offer.to].indexOf(offer.from)<candidates[offer.to].indexOf(arr[indexOfCand].company)){
          arr[indexOfCand].company = offer.to;
        }
      }
    }
    test('matching stops at right point', function(){
      assert(run.out.length <= arr.length);
    })

    //Test 4: Offers are made in order of preference
    let companies1 = companies.map(r => r.map(c => c));
    let candidates1 = candidates.map(r => r.map(c => c));
    let bool = run.trace.every(o =>{
      if(o.fromCo && companies1[o.from].indexOf(o.to) === 0){
        let newPrefList = companies1[o.from].slice(1, companies1[o.from].length);
        companies1[o.from] = newPrefList;
        return true;
      }
      else if(!o.fromCo && candidates1[o.from].indexOf(o.to) === 0){
        let newPrefList = candidates1[o.from].slice(1, candidates1[o.from].length);
        candidates1[o.from] = newPrefList;
        return true;
      }else{
        return false
      }
    })
    test('Every Offer is made in correct preference order', function(){
      assert(bool);
    })



  }
}

const oracleLib = require('oracle');
runOracle(oracleLib.traceWheat1);
runOracle(oracleLib.traceChaff1)

//This is a function I made to test generateInput by using Property Based Testing
function testGenerateInput(){
  let numTests = 10;
  for(let i =0; i<numTests; ++i){
    let n = randomInt(0,10);
    let arr = generateInput(n)

    //This tests whether generateInput uses all values from 0-n
    test('All numbers 0-n are used', function(){
      let arrN = []
      for(let i =0; i<n; ++i){
        arrN.push(n)
      }
      let tempArrN = arrN;
      for(let i=0; i<arr.length; ++i){
        for(let j =0; j<arr[i].length; ++j){
          let num = arr[i][j];
          let numIndex = arrN.indexOf(num)
          arrN.splice(numIndex, 1);
        }
        assert(arrN.length === 0)
        arrN = tempArrN;
      }
    })
    
    //This tests whether generateInput repeats numbers in any row
    test('numbers are not repeated in any row', function(){
      let numDup = 0;
      let valuesSoFar = [];
      for(let i =0; i<arr.length; ++i){
        if(valuesSoFar.includes(arr[0][i])){ numDup +=1 }
        valuesSoFar.push(arr[0][i]);
        if(i === arr.length-1){ valuesSoFar = [] }
      }
      assert(numDup === 0);
    })

    //This tests whether generateInput returns the correct size array
    test('array is correct size', function(){
      assert(arr.length === n) // this checks that there are n arrays
      for(let j =0; j<arr.length; ++j){
        assert(arr[j].length === n) // this checks that each row has n values
      }
    })
    

  }
}
testGenerateInput()