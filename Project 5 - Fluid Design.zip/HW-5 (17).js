function doAction(r, str, compVal, f){
  let property = lib220.getProperty(r, str);
  if(property.found && f(property.value)){
    return true;
  }else{
    return false;
  }
}

function reducer(acc, e, str1, str2){
  let prop = lib220.getProperty(e, str1);
  let a = acc.stars;
  let b = acc.review_count;
  if(str1 === 'review_count'){
    a = acc.review_count;
    b = acc.stars;
  }
  if(prop.found && prop.value > a){
      return e;
  }
  else if(prop.found && prop.value === a){
    let cProp = lib220.getProperty(e, str2);
    if(cProp.found && cProp.value > b){
      return e;
    }
  }
  return acc;
}

function emptyObj(obj){
  if(obj.stars === -1 && obj.review_count === -1){
    return {};
  }else{
    return obj;
  }
}

class FluentRestaurants{
  constructor(jsonData) {
    this.data = jsonData;
  }

  //fromState(stateStr: string): FluentRestaurants
  fromState(stateStr){
    return new FluentRestaurants(this.data.filter(r=> doAction(r, 'state', stateStr, x=> x === stateStr)));
  }
  
  //ratingLeq(rating: number): FluentRestaurants
  ratingLeq(rating){
    return new FluentRestaurants(this.data.filter(r=> doAction(r, 'stars', rating, x=> x <= rating)));
  }

  //ratingGeq(rating: number): FluentRestaurants
  ratingGeq(rating){
    return new FluentRestaurants(this.data.filter(r=> doAction(r, 'stars', rating, x=> x >= rating)));
  }

  //category(categoryStr: string): FluentRestaurants
  category(categoryStr){
    return new FluentRestaurants(this.data.filter(r=> doAction(r, 'categories', categoryStr, a => a.includes(categoryStr))));
  }

  //hasAmbience(ambienceStr: string): FluentRestaurants  
  //Also you have to check if attributes exists
  hasAmbience(ambienceStr){
    return new FluentRestaurants(this.data.filter(r => lib220.getProperty(r, 'attributes').found && doAction(r.attributes, 'Ambience', ambienceStr, x => lib220.getProperty(x, ambienceStr).value === true)));
  }

  //bestPlace(): Restaurant | {}
  bestPlace(){
    return emptyObj(this.data.reduce((acc, e) => reducer(acc, e, 'stars', 'review_count'), {stars: -1, review_count: -1}))
  }

  //mostReviews(): Restaurant | {}
  mostReviews(){
    return emptyObj(this.data.reduce((acc, e) => reducer(acc, e, 'review_count', 'stars'), {stars: -1, review_count: -1}))
  }

}



let data = lib220.loadJSONFromURL('https://people.cs.umass.edu/~joydeepb/yelp.json');
let f = new FluentRestaurants(data);
console.log(data.length);
console.log(f.fromState('NC').data.length);
console.log(f.ratingLeq(2).data.length);
console.log(f.ratingGeq(2).data.length);
console.log(f.category("Food").data.length);
console.log(f.hasAmbience('hipster').data.length);
console.log(f.fromState('NC').bestPlace());



const testData = [
  {
    name: "Applebee's",
    state: "NC",
    stars: 4,
    review_count: 6,
    categories: [
      "Shopping",
      "Shopping Centers",
      "Food"
    ],
    attributes: {
      GoodForMeal: {
        dessert: false,
        brunch: false
      },
      HasTV: false,
      RestaurantsGoodForGroups: true,
      Ambience: {
        romantic: false,
        intimate: false,
        classy: true
      }
    },
  },
  {
    name: "China Garden",
    state: "NC",
    stars: 4,
    review_count: 10,
    categories: [
      "Shopping",
      "Shopping Centers"
    ],
    attributes: {
      GoodForMeal: {
        dessert: false,
        brunch: false
      },
      HasTV: false,
      RestaurantsGoodForGroups: true,
      Ambience: {
        romantic: false,
        intimate: false,
        classy: false
      }
    },
  },
  {
    name: "Beach Ventures Roofing",
    state: "AZ",
    stars: 3,
    review_count: 30,
    categories: [
      "Shopping",
      "Shopping Centers",
      "Food"
    ],
    attributes: {
      GoodForMeal: {
        dessert: false,
        brunch: false
      },
      HasTV: false,
      RestaurantsGoodForGroups: true,
      Ambience: {
        romantic: false,
        intimate: false,
        classy: true
      }
    },
  },
  {
    name: "Alpaul Automobile Wash",
    state: "NC",
    stars: 3,
    review_count: 30,
    attributes: {
      GoodForMeal: {
        dessert: false,
        brunch: false
      },
      HasTV: false,
      RestaurantsGoodForGroups: true
    },
  }
];
test('fromState filters correctly', function() {
  let tObj = new FluentRestaurants(testData);
  let list = tObj.fromState('NC').data;
  assert(list.length === 3);
  assert(list[0].name === "Applebee's");
  assert(list[1].name === "China Garden");
  assert(list[2].name === "Alpaul Automobile Wash");
});

test('ratingLeq filters correctly', function(){
  let tObj = new FluentRestaurants(testData);
  let list = tObj.ratingLeq(3).data;
  assert(list.length === 2)
  assert(list[0].name === "Beach Ventures Roofing")
  assert(list[1].name === "Alpaul Automobile Wash")
});

test('ratingGeq filters correctly', function(){
  let tObj = new FluentRestaurants(testData);
  let list = tObj.ratingGeq(3).data;
  assert(list.length === 4)
  assert(list[0].name === "Applebee's")
  assert(list[1].name === "China Garden")
  assert(list[2].name === "Beach Ventures Roofing")
  assert(list[3].name === "Alpaul Automobile Wash")
});

test('category filters correctly', function(){
  let tObj = new FluentRestaurants(testData);
  let list = tObj.category('Food').data;
  assert(list.length === 2);
  assert(list[0].name === "Applebee's")
  assert(list[1].name === "Beach Ventures Roofing");
});

test('hasAmbience', function(){
  let tObj = new FluentRestaurants(testData);
  let list = tObj.hasAmbience('classy').data;
  assert(list.length === 2);
  assert(list[0].name === "Applebee's")
  assert(list[1].name === "Beach Ventures Roofing");
});

test('bestPlace tie-breaking', function() {
  let tObj = new FluentRestaurants(testData);
  let place = tObj.fromState('NC').bestPlace();
  assert(place.name === 'China Garden');
});
test('empty obj returned by bestPlace & mostReviews', function(){
  const data = [
    {
      name: "Applebee's",
      state: "NC",
    },
    {
      name: "China Garden",
      state: "NC",
    }
  ];
  let tObj = new FluentRestaurants(data);
  let place = tObj.bestPlace();
  assert(Object.keys(place).length === 0);
  let p2 = tObj.mostReviews();
  assert(Object.keys(p2).length === 0);

});

test('mostReviews tie-breaking', function(){
  let tObj = new FluentRestaurants(testData);
  let place = tObj.mostReviews();
  assert(place.name === 'Beach Ventures Roofing');
});

