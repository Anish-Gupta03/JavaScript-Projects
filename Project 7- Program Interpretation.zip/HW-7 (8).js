//Performs numerical operations only on 2 numbers
function numericalOperator(state, e, f){
  if(typeof interpExpression(state, e.e1) === 'number' && typeof interpExpression(state, e.e2) === 'number'){
    return f(interpExpression(state, e.e1), interpExpression(state, e.e2))
  }else{
    console.log('Both values must be numbers in order to use a numerical operator');
    assert(false);
  }
}
//this function gets the first variable with the name you are looking for searching from the inner scope to outer scope.
//for example if you had a scope of {let x = 10; {let x=5 {let x=4 {let y = 19}}}} it would return 4 when searching for x.
function valInOuterScope(state, e){
  if(lib220.getProperty(state, 'outerScopeLink').found){
    if(lib220.getProperty(state.outerScopeLink, e.name).found){
      return lib220.getProperty(state.outerScopeLink, e.name).value;
    }else{ 
      return valInOuterScope(state.outerScopeLink, e); 
    }
  }else{
    console.log('variable is not in any of the scopes: ' +e.name)
    assert(false);
  }
}
//Checks if an outerScope exists, and if it does it will check for the variable and do assignment if it exists.
function hasOuterScope(state, s){
  if(lib220.getProperty(state, 'outerScopeLink').found){
    if(lib220.getProperty(state.outerScopeLink, s.name).found){
      let value = interpExpression(state, s.expression);
      lib220.setProperty(state.outerScopeLink, s.name, value);
      return true;
    }else{
      return hasOuterScope(state.outerScopeLink, s)
    }
  }
  return false;
}

// interpExpression(state: State, e: Expr): number | boolean
function interpExpression(state, e) {
  if (e.kind === 'number') {
    return e.value;
  }
  if (e.kind === 'boolean'){
    return e.value;
  }
  else if (e.kind === 'operator') {
    switch(e.op){
      case '+': { return numericalOperator(state, e, (v1, v2) => v1+v2); }
      case '-': { return numericalOperator(state, e, (v1, v2) => v1-v2); }
      case '/': { return numericalOperator(state, e, (v1, v2) => v1/v2); }
      case '*': { return numericalOperator(state, e, (v1, v2) => v1*v2); }
      case '>': { return numericalOperator(state, e, (v1, v2) => v1>v2); }
      case '<': { return numericalOperator(state, e, (v1, v2) => v1<v2); }
      case '&&': {
        if(typeof interpExpression(state, e.e1) === 'boolean' && !interpExpression(state, e.e1)){
          console.log('short circuit because first expression was false');
          return false;
        }
        else if(typeof interpExpression(state, e.e1) === 'boolean' && typeof interpExpression(state, e.e2) === 'boolean'){
          return interpExpression(state, e.e1) && interpExpression(state, e.e2);
        }
        console.log('Both values are not booleans and thus cannot be compared using the && operator');
        assert(false);
        break;
      }
      case '||': {
        if(typeof interpExpression(state, e.e1) === 'boolean' && interpExpression(state, e.e1)){
          console.log('short circuit because first expression was true');
          return true;
        }
        else if(typeof interpExpression(state, e.e1) === 'boolean' && typeof interpExpression(state, e.e2) === 'boolean'){
          return interpExpression(state, e.e1) || interpExpression(state, e.e2);
        }
        console.log('Both values are not booleans and thus cannot be compared using the || operator');
        assert(false);
        break;
      }
      case '===': { return interpExpression(state, e.e1) === interpExpression(state, e.e2); }
    }
  }
  else if (e.kind === 'variable') {
    if(lib220.getProperty(state, e.name).found){
      return lib220.getProperty(state, e.name).value;
    } else {  
      return valInOuterScope(state, e); 
    }
  } else {
    console.log('unknown error: may be due to unsupported expression')
    assert(false)
  }
}

// interpStatement(state: State, p: Stmt): void
function interpStatement(state, s) {
  function interpBlock(state, stmts){
    let scope = {outerScopeLink: state}
    stmts.forEach(s=> interpStatement(scope, s))
  }
  switch(s.kind){
    case 'let': {
      if(lib220.getProperty(state, s.name).found){
        console.log('duplicate declaration')
        assert(false);
        break;
      }
      let value = interpExpression(state, s.expression);
      lib220.setProperty(state, s.name, value);
      break;
    }
    case 'assignment': {
      if(!lib220.getProperty(state, s.name).found){
        if(hasOuterScope(state, s)){
          break;
        }else{
          console.log('variable not found and thus cannot be assigned before being declared');
          assert(false);
          break;
        }
      }
      let value = interpExpression(state, s.expression);
      lib220.setProperty(state, s.name, value);
      break;
    }
    case 'if': {
      let value = interpExpression(state, s.test);
      if (value) {
        interpBlock(state, s.truePart);
      } else {
        interpBlock(state, s.falsePart);
      }
      break;
    }
    case 'while': {
      while (interpExpression(state, s.test)){
        interpBlock(state, s.body);
      }
      break;
    }
    case 'print': {
      let value = interpExpression(state, s.expression);
      console.log(value);
      break;
    }
  }
}

// interpProgram(p: Stmt[]): State
function interpProgram(stmts){
  let state = {};
  stmts.forEach(s=> interpStatement(state, s));
  return state;
}



// parseExpression(str: string): Result<Expr>
// parseProgram(str: string): Result<Stmt[]>
test("interpExpression works", function() {
  let r = interpExpression({ x: 10 }, parser.parseExpression("x * 2").value);
  assert(r === 20);
  let c = interpExpression({ x: 10 }, parser.parseExpression("x / 2+1").value);
  assert(c === 6);
  let m = interpExpression({ x: 10 }, parser.parseExpression("x / 2+1-5*7").value);
  assert(m === -29)
  let d = interpExpression({x:20}, parser.parseExpression("x>4").value)
  assert(d)
  let e = interpExpression({}, parser.parseExpression("true && false").value)
  assert(!e)
  let f = interpExpression({}, parser.parseExpression("true || false").value)
  assert(f)
});

test('interpStatement let works', function(){
  let st = interpProgram(parser.parseProgram("let x = 10;").value);
  console.log(st)
  assert(st.x === 10);
})

test('interpStatement assignment works', function(){
  let st = interpProgram(parser.parseProgram("let x = 10; x = 20;").value);
  console.log(st)
  assert(st.x === 20);
})
test("interpStatement if works", function(){
  let state = interpProgram(parser.parseProgram("let x = 3; " + "let y = 0; " + "if (x < 0) { " + " y = -1; " + "} else { " + " y = 1; " + "}").value)
  console.log(state)
  assert(state.y === 1)
  let st = interpProgram(parser.parseProgram("let x = 10; " + " if (x<10) { " + " let y = x - 1; " + " x = x+1; " + " } else { " + " print(x); "+ "} ").value)
});
test('interpStatement while works', function(){
  let st = interpProgram(parser.parseProgram("let x = 3; " + "let y = 0; " + "while (x > 0) { " + " y = y-1; " + " x = x-1; " + "}").value)
  console.log(st);
  assert(st.y === -3)
}) 
test('factorial', function(){
  let st = interpProgram(parser.parseProgram("let x = 8; let num = 1; if(x===0){x=1;}else{} while(x-1 > 0){let y =3; num = num*x; x = x-1;}").value)
  console.log(st)
  assert(st.num === 40320)
})
test('interpProgram works', function(){
  let st = interpProgram(parser.parseProgram("let x = 10; while(x > 0){if(x === 2){let y = 2; print(y);}else{} x = x-2;}").value) 
  console.log(st);
  assert(st.x === 0)
  let p = parser.parseProgram("let x=10; if(x===10){let y = 4;}else{} while(x>0){let z = 2; x = x-1;}").value;
  p[2].body[0].name = 'y';
  let r = interpProgram(p)
  console.log(r)
  assert(r.x===0)
})

test('fibonacci sequence', function(){
  let st = interpProgram(parser.parseProgram("let i=1; let count = 8; let numOne = 0; let numTwo = 1; while(i<count) { print(numOne); let sumOfPrevTwo = numOne + numTwo; numOne = numTwo; numTwo = sumOfPrevTwo; i = i+1; }").value)
  console.log(st)
  assert(st.i === 8 && st.count ===8 && st.numOne === 13 && st.numTwo === 21)
})
test('scoping test', function(){
  let st = interpProgram(parser.parseProgram('let i = 3; while(i>0){ let z = 2; i= z-2;}').value)
  console.log(st)
})
test('scoping test 2', function(){
  let st = interpProgram(parser.parseProgram('let i = 22; if(i>0){i = 31; if(i>0){ i = 23;}else{}}else{}').value)
  console.log(st);
  assert(st.i === 23)
})
test('scoping test 3', function(){
  let st = interpProgram(parser.parseProgram("let x = 20; if(true){ x=15; if(true){ x=232; if(true){ x=98; }else{}}else{}}else{}").value);
  console.log(st);
  assert(st.x === 98)
})
test('short circuit &&', function(){
  let e = interpExpression({ x: 10 }, parser.parseExpression("false && x").value);
  console.log(e)
  assert(e === false);
})
test('short circuit ||', function(){
  let e = interpExpression({ x: 10 }, parser.parseExpression("true || x").value);
  console.log(e)
  assert(e === true);
})
test('interpExpression edge Cases', function(){
  let e = interpExpression({ inf: Infinity }, parser.parseExpression("inf > inf").value);
  console.log(e)
  assert(e === false);

  let exp = interpExpression({inf: Infinity, negInf: -Infinity}, parser.parseExpression("inf > negInf").value)
  console.log(exp)
  assert(exp === true);
})
