let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');
//robot.show();


function removeBlueAndGreen(robot){
  let copyImage = robot.copy();
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let color = copyImage.getPixel(i, j);
      copyImage.setPixel(i, j, [color[0], 0.0, 0.0])
    }
  }
  copyImage.show();
  return copyImage;
}

function shiftRGB(robot){
  let copyImage = robot.copy();
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let color = copyImage.getPixel(i, j);
      copyImage.setPixel(i, j, [color[1], color[2], color[0]])
    }
  }
  copyImage.show();
  return copyImage;
}
//removeBlueAndGreen(robot);
//shiftRGB(robot);

function imageMap(img, p){
  let copyImage = img.copy();
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let colorArray = copyImage.getPixel(i, j);
      colorArray = p(colorArray);
      copyImage.setPixel(i, j, colorArray);
    }
  }
  //copyImage.show();
  return copyImage;
}

function mapToRed(img){
  let copyImage = imageMap(img, colorArray => [colorArray[0], 0.0, 0.0]);
  copyImage.show();
  return copyImage;
}
function mapToGBR(img){
  let copyImage = imageMap(img, colorArray => [colorArray[1], colorArray[2], colorArray[0]]);
  copyImage.show();
  return copyImage;
}
mapToRed(robot);
mapToGBR(robot);


function increaseContrast(img){
  /*
  colorArray = colorArray.map(changeLimit);
  return colorArray;
  */
  let copyImage = imageMap(img, colorArray => colorArray.map(changeLimit));
  copyImage.show();
  return copyImage;
}
increaseContrast(robot);

function changeLimit(value){
  if(value < 0.5){
    value = value - (value*0.1);
  }else{
    value = value + ((1-value)*0.1);
  }
  return value;
}