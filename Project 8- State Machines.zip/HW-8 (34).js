class FSA{
  constructor(){

    class State{
      constructor(n){
        let state = {name: n, transitions: []};
        this.getName = () =>{ 
          if(state === undefined){ 
            return undefined;
          }else{ 
            return state.name; 
          }
        }
        this.setName = newName =>{ state.name = newName; return this; }
        this.addTransition = (e, st) =>{
          // let t = {};
          // lib220.setProperty(t, 'source', e);
          // lib220.setProperty(t, 'target', st);
          // state.transitions.push(t); 
          state.transitions.push({source: e, target: st}); 
          return this; 
        }
        this.nextState = e =>{
          //console.log(state)
          let arr = state.transitions.filter(o=> o.source === e);
          if(arr.length >= 1){
            let num = Math.floor(Math.random()*arr.length);
            return arr[num].target;
          }
          return undefined;
        }
        this.nextStates = e =>{
          let successorStates = [];
          state.transitions.filter(o=> o.source === e).forEach(o=> succesorStates.push(o.target)); 
          return successorStates;
        }
        this.removeTransitions = () => state.transitions = [];
      }
    }

    class Memento {
      constructor(){
        let stateName = undefined;
        this.storeState = s =>  stateName = s; 
        this.getState = () => stateName; 
      }
    }

    this.nextState = e => { 
      if(curState === undefined){ return this; }
      curState = curState.nextState(e);
      return this;
    }

    this.createState = (s, transitionArr) =>{
      let newState = new State(s);
      //this takes the transition array and updates the transitions in the new state we just made
      transitionArr.forEach(t=>{
        let e = Object.keys(t)[0];
        let targetName = Object.values(t)[0];
        //checks if stateArr has some state with the name of the target state
        if(stateArr.some(st => st.getName() === targetName)){ 
          for(let i =0; i<stateArr.length; ++i){
            //if state array has a state with the same name as the target, it will add the transition using that state
            if(stateArr[i].getName() === targetName){ 
              newState.addTransition(e, stateArr[i]); 
              break; 
            }
          }
        }else{
          //defines target state since there was no state with its name
          let nST = new State(targetName);
          stateArr.push(nST);
          newState.addTransition(e, nST);
        }
      });
      //If there exists some state in the state array which has the same name as the state i just created, then overide the state in state array
      if(stateArr.some(st => st.getName() === newState.getName())){
        stateArr.forEach(stf =>{ 
          if(stf.getName() === newState.getName()){ 
            stf.removeTransitions();
            transitionArr.forEach(t=>{
              let e = Object.keys(t)[0];
              let targetName = Object.values(t)[0];
              if(stateArr.some(st => st.getName() === targetName)){ 
                for(let i =0; i<stateArr.length; ++i){
                  if(stateArr[i].getName() === targetName){ 
                    stf.addTransition(e, stateArr[i]); 
                    break; 
                  }
                }
              }else{
                let nST = new State(targetName);
                stateArr.push(nST);
                stf.addTransition(e, nST);
              }
            });
          }
        });
      }else{
        stateArr.push(newState);
      }
      if(curState === undefined){ curState = newState };
      return this;
    }

    this.addTransition = (s, transition) => {
      //This checks if the state array has that state. If not it will make the state.
      if(!stateArr.some(st => st.getName() === s)){ this.createState(s, [transition]); return this; }
      let e = Object.keys(transition)[0];
      let targetName = Object.values(transition)[0];
      //If the source state exists but target state doesn't exist, it will make that as well.
      if(!stateArr.some(st => st.getName() === targetName)){ this.createState(targetName, []) }
      for(let i = 0; i<stateArr.length; ++i){
        if(stateArr[i].getName() === s){
          for(let j = 0; j<stateArr.length; ++j){
            if(stateArr[j].getName() === targetName){ stateArr[i].addTransition(e, stateArr[j]); break; }
          }
          break;
        }
      }
      return this;
    }
      
    this.showState = () =>{ 
      if(curState === undefined){ return undefined; }
      return curState.getName();
    }
    //MAKE SURE TO RENAME ALL THE TRANSITIONS THAT POINT TO IT AS WELL
      //Edit: nvm it works because when the state name gets changed it automatically is changed in the transitions as well.
    this.renameState = (oldName, newName) =>{ 
      stateArr.forEach(s =>{
        if(s.getName() === oldName){
          s.setName(newName);
        }
      });
      return this; 
    }
    this.createMemento = () =>{ 
      let mem = new Memento();
      mem.storeState(curState.getName());
      return mem;
    }
    this.restoreMemento = m =>{
      let sname = m.getState();
      for(let i =0; i<stateArr.length; ++i){
        if(stateArr[i].getName() === sname){
          curState = stateArr[i];
          break;
        }
      } 
      return this; 
    }

    let curState = undefined;
    let stateArr = [];
  }
}

test('createState is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  assert(myMachine.showState() === "delicates, low")

  let machine2 = new FSA()
  .createState("A", [{mode: "1"}, {temp: "2"}])
  .createState("B", [{mode: "23"}, {temp: "4"}])
  .createState("B", [{mode: "33"}, {temp: "5"}])
  assert(machine2.showState() === "A")
})

test('nextState is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  .nextState("temp")
  assert(myMachine.showState() === "delicates, medium")
  myMachine.nextState("mode")
  assert(myMachine.showState() === "normal, medium")
  myMachine.nextState("temp") 
  assert(myMachine.showState() === "normal, high")
})
test('createMemento is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  let memento = myMachine.createMemento();
  myMachine.nextState("mode")
  assert(myMachine.showState() === "normal, low")
  assert(memento.getState() === "delicates, low")
})
test('restoreMemento is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  .nextState("temp")
  .nextState("mode")
  .nextState("temp") 
  let restoreTo = myMachine.createMemento();
  myMachine.nextState("mode")
  .nextState("temp")
  assert(myMachine.showState() === "delicates, low");
  myMachine.restoreMemento(restoreTo)
  assert(myMachine.showState() === "normal, high");
})
test('addTransition is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .addTransition("delicates, low", {otherButton: "delicates, medium"})
  .nextState("otherButton");
  assert(myMachine.showState() === "delicates, medium")

  let machine2 = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  //CAN ADD TRANSITION MAKE A NEW TARGET STATE AS WELL?
  .addTransition("normal, high", {otherButton: "newState"})
  .nextState("mode")
  .nextState("temp")
  .nextState("temp")
  .nextState("otherButton")
  console.log(machine2.showState())
  assert(machine2.showState() === "newState")

  let machine3 = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  .addTransition("normal, high", {otherButton: "normal, low"})
  .nextState("mode")
  .nextState("temp")
  .nextState("temp")
  .nextState("otherButton")
  console.log(machine3.showState())
  assert(machine3.showState() === "normal, low")

})

test('showState is functional', function(){
  let machine3 = new FSA();
  assert(machine3.showState() === undefined);

  machine3.createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  assert(machine3.showState() === "delicates, low")

  machine3.createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .nextState("mode");
  assert(machine3.showState() === "normal, low")
})

test('renameState is functional', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .renameState("delicates, low", "NEW NAME");
  assert(myMachine.showState() === "NEW NAME")
  myMachine.renameState("delicates, medium", "NEWER NAME")
  .nextState("temp")
  assert(myMachine.showState() === "NEWER NAME")
})

test('renaming a state and then next state works', function(){
  let myMachine = new FSA()
  .createState("delicates, low", [{mode: "normal, low"}, {temp: "delicates, medium"}])
  .createState("normal, low", [{mode: "delicates, low"}, {temp: "normal, medium"}])
  .createState("delicates, medium", [{mode: "normal, medium"}, {temp: "delicates, low"}])
  .createState("normal, medium", [{mode: "delicates, medium"}, {temp: "normal, high"}])
  .createState("normal, high", [{mode: "delicates, medium"},{temp: "normal, low"}])
  .renameState("delicates, low", "hello")
  .nextState("temp")
  assert(myMachine.showState() === "delicates, medium")
})

test('renaming a state and then adding a transition and then calling next state works', function(){
  let myMachine = new FSA()
  .createState('A', [{t1: 'B'}, {t2: 'C'}])
  .createState('B', [{t1: 'A'}])
  .renameState('A', 'N')
  .nextState('t1')
  assert(myMachine.showState() === 'B')

  let myMachine2 = new FSA()
  .createState('A', [{t1: 'B'}, {t2: 'C'}])
  .createState('B', [{t1: 'A'}])
  .renameState('B', 'N')
  .nextState('t1')
  assert(myMachine2.showState() === 'N')
})

test('double rename state with nextState', function(){
  let myMachine = new FSA()
  .createState('yes', [{change: 'no'}])
  .createState('no', [{change: 'yes'}])
  .renameState('yes', 'y')
  .renameState('no', 'n')
  .nextState('change')
  console.log(myMachine.showState())
  assert(myMachine.showState() === 'n')
  myMachine.nextState("change")
  console.log(myMachine.showState())
  assert(myMachine.showState() === 'y')
})

test('chained calls work', function(){
  let myMachine = new FSA()
  .createState("A", [{t1: "B"}, {t2: "C"}])
  .createState("D", [{t1:"C"}])
  .createState("B", [{t1: "C"}])
  .createState("C", [{t1: "A"}])
  .nextState("t1")
  //state should now be B.
  .renameState("B", "newB");
  assert(myMachine.showState() === "newB")

  myMachine.addTransition("C", {t2: "D"})
  .nextState("t1")
  //staet should now be C
  .nextState("t2")
  //state should now be D
  assert(myMachine.showState() === "D")
})

test('nextState several moves', function(){
  let myMachine = new FSA()
  .createState("A", [{t1: "B"}, {t1: "C"}, {t2: "E"}])
  .nextState("t1")
  console.log(myMachine.showState())
  for(let i = 0; i< 20; ++i){
    assert(myMachine.showState() === "B" || myMachine.showState() === "C")
  }
})

test('showState returns undefined', function(){
  let myMachine = new FSA();
  console.log(myMachine.showState());
  assert(myMachine.showState() === undefined)
})
