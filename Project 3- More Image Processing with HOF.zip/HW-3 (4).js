let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel): Image
function imageMapXY(img, pixelFunction){
  let copyImage = img.copy();
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let pixel = pixelFunction(copyImage, i, j);
      copyImage.setPixel(i, j, pixel);
    }
  }
  return copyImage;
}

//blurPixel(img: Image, x: number, y: number): Pixel
function blurPixel(img, x, y){
  let redChannel = 0;
  let greenChannel = 0;
  let blueChannel = 0;
  let neighbors = 0;
  for(let a=x-1; a<=x+1; ++a){
    for(let b=y-1; b<=y+1; ++b){
      if(a>=0 && b>=0 && a<img.width && b<img.height){
        redChannel = redChannel + img.getPixel(a,b)[0]
        greenChannel = greenChannel + img.getPixel(a,b)[1]
        blueChannel = blueChannel + img.getPixel(a,b)[2]
        neighbors = neighbors+1
      }
    }
  }
  redChannel = redChannel/neighbors;
  greenChannel = greenChannel/neighbors;
  blueChannel = blueChannel/neighbors;
  return [redChannel, greenChannel, blueChannel];

}

//blurImage(img: Image): Image
function blurImage(img){
  return imageMapXY(img, blurPixel);
}
//robot.show()
//blurImage(robot).show()

//diffLeft(img: Image, x: number, y: number): Pixel
function diffLeft(img, x, y){
  let pixel = [];
  let leftPixel = [];
  if(x>= 0 && x<img.width && y>=0 && y<img.height){
    pixel = img.getPixel(x,y);
  }
  if(x-1>=0 && x-1<img.width && y>=0 && y<img.height){
    leftPixel = img.getPixel(x-1,y);
  }else{
    return [0, 0, 0];
  }
  let m1 = pixel.reduce((acc, e) => acc+e, 0)/3;
  let m2 = leftPixel.reduce((acc, e) => acc+e, 0)/3;
  let mean = Math.abs(m2-m1);
  return [mean, mean, mean];
}

function highlightEdges(img){
  return imageMapXY(img, diffLeft);
}

highlightEdges(robot).show();

//reduceFunctions(fa: ((p: Pixel) => Pixel)[] ): ((x: Pixel) => Pixel)
// a function array that takes an array of pixels and returns an array of pixels
// reduceFunctions returns a function that returns a pixel
function reduceFunctions(functionArray){
  return p => functionArray.reduce((acc,fxn) => fxn(acc), p);
}
//console.log(reduceFunctions( [function f(p){ return [1,2,3] } , function g(p){ return [2,34,4] } , function h(p){ [5,6,7] } ] ))

//combineThree(img: Image): Image
function combineThree(img){
  return imageMap(img, reduceFunctions([makeGrayish, blackenLow, shiftRGB]))
}
//combineThree(robot).show()




function imageMap(img, pFunc){
  let copyImage = img.copy();
  for(let i=0; i<copyImage.width; ++i){
    for(let j=0; j<copyImage.height; ++j){
      let pixel = copyImage.getPixel(i, j);
      pixel = pFunc(pixel);
      copyImage.setPixel(i, j, pixel);
    }
  }
  return copyImage;
}

function makeGrayish(p){
  let max = p.reduce((a,b) => Math.max(a,b), p[0]);
  let min = p.reduce((a,b) => Math.min(a,b), p[0]);
  let diff = max-min;
  if(diff <= (1/3)){
    return p;
  }else{
    let avg = (p[0] + p[1] + p[2])/3;
    return [avg, avg, avg];
  }
}

function blackenLow(p){
  if(p[0] < (1/3)){ p[0] = 0; }
  if(p[1] < (1/3)){ p[1] = 0; }
  if(p[2] < (1/3)){ p[2] = 0; }
  return p;
}

function shiftRGB(p){
  return [p[1], p[2], p[0]];
}

function pixelEq (p1, p2) {
const epsilon = 0.002; // increase for repeated storing & rounding
return [0,1,2].every(i => Math.abs(p1[i] - p2[i]) <= epsilon);
};

test("testing blurPixel edge case", function(){
  //checking 0,0 because it only has 3 neighbors
  let neighbors = 4;
  let redChannel = (robot.getPixel(0,0)[0] + robot.getPixel(1,0)[0] + robot.getPixel(1,1)[0] + robot.getPixel(0,1)[0])/neighbors
  let greenChannel = (robot.getPixel(0,0)[1] + robot.getPixel(1,0)[1] + robot.getPixel(1,1)[1] + robot.getPixel(0,1)[1])/neighbors
  let blueChannel = (robot.getPixel(0,0)[2] + robot.getPixel(1,0)[2] + robot.getPixel(1,1)[2] + robot.getPixel(0,1)[2])/neighbors
  assert(pixelEq(blurPixel(robot, 0, 0), [redChannel, greenChannel, blueChannel]))
})

test("testing blurImage", function(){
  //checking a random pixel
  let neighbors = 9;
  let redChannel = (robot.getPixel(5,5)[0] + robot.getPixel(4,5)[0] + robot.getPixel(6,5)[0] + robot.getPixel(5,6)[0] 
  +robot.getPixel(5, 4)[0] + robot.getPixel(4, 4)[0] + robot.getPixel(6, 6)[0] + robot.getPixel(4,6)[0] 
  + robot.getPixel(6, 4)[0])/neighbors
  let greenChannel = (robot.getPixel(5,5)[1] + robot.getPixel(4,5)[1] + robot.getPixel(6,5)[1] + robot.getPixel(5,6)[1] 
  +robot.getPixel(5, 4)[1] + robot.getPixel(4, 4)[1] + robot.getPixel(6, 6)[1] + robot.getPixel(4,6)[1] 
  + robot.getPixel(6, 4)[1])/neighbors
  let blueChannel = (robot.getPixel(5,5)[2] + robot.getPixel(4,5)[2] + robot.getPixel(6,5)[2] + robot.getPixel(5,6)[2] 
  +robot.getPixel(5, 4)[2] + robot.getPixel(4, 4)[2] + robot.getPixel(6, 6)[2] + robot.getPixel(4,6)[2] 
  + robot.getPixel(6, 4)[2])/neighbors
  assert(pixelEq(blurPixel(robot, 5, 5), [redChannel, greenChannel, blueChannel]))
  //checking another pixel
  neighbors = 4;
  redChannel = (robot.getPixel(0,0)[0] + robot.getPixel(1,0)[0] + robot.getPixel(1,1)[0] + robot.getPixel(0,1)[0])/neighbors
  greenChannel = (robot.getPixel(0,0)[1] + robot.getPixel(1,0)[1] + robot.getPixel(1,1)[1] + robot.getPixel(0,1)[1])/neighbors
  blueChannel = (robot.getPixel(0,0)[2] + robot.getPixel(1,0)[2] + robot.getPixel(1,1)[2] + robot.getPixel(0,1)[2])/neighbors
  assert(pixelEq(blurPixel(robot, 0, 0), [redChannel, greenChannel, blueChannel]))
})

test("testing diffLeft", function(){
  let pixel = (robot.getPixel(5,5)[0] + robot.getPixel(5,5)[1] + robot.getPixel(5,5)[2])/3
  let leftPixel = (robot.getPixel(4,5)[0] + robot.getPixel(4,5)[1] + robot.getPixel(4,5)[2])/3
  let mean = Math.abs(leftPixel-pixel)
  assert(pixelEq(diffLeft(robot, 5, 5), [mean, mean, mean]))
  //testing where there is no left pixel
  pixel = (robot.getPixel(0,0)[0] + robot.getPixel(0,0)[1] + robot.getPixel(0,0)[2])/3
  assert(pixelEq(diffLeft(robot, 0, 0), [pixel, pixel, pixel]))

})

test("testing highlightEdges", function(){
  let pixel = (robot.getPixel(66,66)[0] + robot.getPixel(66,66)[1] + robot.getPixel(66,66)[2])/3
  let leftPixel = (robot.getPixel(65,66)[0] + robot.getPixel(65,66)[1] + robot.getPixel(65,66)[2])/3
  let mean = Math.abs(leftPixel-pixel)

  assert(pixelEq(diffLeft(robot, 66, 66), [mean, mean, mean]))

  pixel = (robot.getPixel(78,66)[0] + robot.getPixel(78,66)[1] + robot.getPixel(78,66)[2])/3
  leftPixel = (robot.getPixel(77,66)[0] + robot.getPixel(77,66)[1] + robot.getPixel(77,66)[2])/3
  mean = Math.abs(leftPixel-pixel)
  assert(pixelEq(diffLeft(robot, 78, 66), [mean, mean, mean]))

  pixel = (robot.getPixel(0,66)[0] + robot.getPixel(0,66)[1] + robot.getPixel(0,66)[2])/3
  assert(pixelEq(diffLeft(robot, 0, 66), [pixel, pixel, pixel]))

  pixel = (robot.getPixel(0,122)[0] + robot.getPixel(0,122)[1] + robot.getPixel(0,122)[2])/3
  assert(pixelEq(diffLeft(robot, 0, 122), [pixel, pixel, pixel]))
})



test("testing combineThree", function(){
  let pixel = robot.getPixel(5,5)
  let pixelAfterTransformation = shiftRGB(blackenLow(makeGrayish(pixel)))
  let combThreeImg = combineThree(robot);
  assert(pixelEq(combThreeImg.getPixel(5,5), pixelAfterTransformation))

  pixel = robot.getPixel(8,102)
  pixelAfterTransformation = shiftRGB(blackenLow(makeGrayish(pixel)))
  combThreeImg = combineThree(robot);
  assert(pixelEq(combThreeImg.getPixel(8,102), pixelAfterTransformation))

  pixel = robot.getPixel(128,102)
  pixelAfterTransformation = shiftRGB(blackenLow(makeGrayish(pixel)))
  combThreeImg = combineThree(robot);
  assert(pixelEq(combThreeImg.getPixel(128,102), pixelAfterTransformation))

  pixel = robot.getPixel(32,76)
  pixelAfterTransformation = shiftRGB(blackenLow(makeGrayish(pixel)))
  combThreeImg = combineThree(robot);
  assert(pixelEq(combThreeImg.getPixel(32,76), pixelAfterTransformation))

})

test("testing reduceFunctions", function(){

  let pixel = shiftRGB(blackenLow(makeGrayish(robot.getPixel(0,0))))
  let finFunc = reduceFunctions([makeGrayish, blackenLow, shiftRGB])
  assert(pixelEq(pixel, finFunc(robot.getPixel(0,0))))

  pixel = shiftRGB(blackenLow(makeGrayish(robot.getPixel(5,5))))
  finFunc = reduceFunctions([makeGrayish, blackenLow, shiftRGB])
  assert(pixelEq(pixel, finFunc(robot.getPixel(5,5))))


})