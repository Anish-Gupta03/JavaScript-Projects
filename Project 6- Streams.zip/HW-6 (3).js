// memo0<T>(f: () => T): Memo<T>
function memo0(f) {
    let r = { evaluated: false };
    return {
        get() {
          if (! r.evaluated) { r = { evaluated: true, v: f() } }
          return r.v;
        }
    };
}
// sempty: Stream<T>
const sempty = {
    isEmpty: () => true,
    toString: () => 'sempty',    
    map: f => sempty,
    filter: pred => sempty,
};
// snode<T>(head: T, tail: Memo<Stream<T>>): Stream<T>
function snode(head, tail) {
    return {
        isEmpty: () => false,
        head: () => head,
        tail: tail.get,
        toString: () => "snode(" + head.toString() + ", " + tail.toString() + ")",
        map: f => snode(f(head), memo0(() => tail.get().map(f))),
        filter: pred => pred(head) ?
                  snode(head, memo0(() => tail.get().filter(pred)))
                : tail.get().filter(pred),
    }
}
function smap(s, f) {
  if (s.isEmpty()) {
    return sempty;
  }
  return snode(f(s.head()), memo0(()=>smap(s.tail(),f)));
}
function concat(s1, s2){
    return s1.isEmpty() ? s2 : snode(s1.head(), memo0(() => concat(s1.tail(), s2)))
  }
function factorial(n){
  if(n === 0 || n === 1){
    return 1;
  }else{
    return n*factorial(n-1);
  }
}


function addSeries(s1, s2){
  if(s1.isEmpty()){ return s2; }
  if(s2.isEmpty()){ return s1; }
  const h1 = s1.head();
  const h2 = s2.head();
  return snode(h1+h2, memo0(() => addSeries(s1.tail(), s2.tail())));
}

// get the head of s. use map and multiply each value of t by the head of s. This gives a0 * t. then create a new stream with 0 
// at the beginning and then use product series(s.tail() *tail) and put those into add series 222
function prodSeries(s, t){
  if(s.isEmpty()){ return sempty; }
  if(t.isEmpty()){ return s; }
  let stream = snode(0, memo0(() => prodSeries(s.tail(), t)))
  return addSeries(stream, smap(t, x => x*s.head()));
}


// Write a function coeff that takes a stream of coefficients for the series s(x) and a natural
// number n, and returns the array of coefficients of s(x), up to and including that of order n.
// If the stream has fewer coefficients, return as many as there are.
function coeff(s, n){
  let arr = [];
  let count = 0;
  while(!s.isEmpty() && count <= n){
    arr.push(s.head());
    count = count+1;
    s = s.tail(); 
  }
  return arr;
}

function derivSeries(s){
  function takeDeriv(index, s){
    if(s.isEmpty()){
      return s;
    }
    // if(s.head() === 0){
    //   return s.tail()
    // }
    return snode(s.head()*index, memo0(() => takeDeriv(index+1, s.tail())));
  }
  return takeDeriv(0, s);
}

function evalSeries(s, n){
  return function(x){
    let coeffList = coeff(s, n);
    let sum = 0;
    for(let i =0; i<coeffList.length; ++i){
      sum = sum+ coeffList[i] * Math.pow(x, i);
    }
    return sum;
  }
}

function rec1Series(f, v){
  return snode(v, memo0(()=> rec1Series(f, f(v))))
}

function expSeries(){
  function taySeries(f, v){
    return snode(f(v), memo0(() => taySeries(f, v+1)))
  }
  return taySeries(k => 1/factorial(k), 0)
}

function recurSeries(coef, init){
  function recurse(coef, init){
    let arr = init.map(x=> x)
    arr.push(prodSum(coef, arr));
    return snode(prodSum(coef, arr), memo0(()=> recurse(coef, arr.slice(1, arr.length))))
  }
  function streamConversion(init, index){
    while(init.length !== index){
      return snode(init[index], memo0(()=> streamConversion(init, index+1)))
    }
    return sempty;
  }
  function prodSum(coef, init){
    let total = 0;
    for(let i =0; i<coef.length; ++i){
      total += coef[i]*init[i]
    }
    return total;
  }
  return concat(streamConversion(init, 0), recurse(coef, init));
}



let stream = snode(1, memo0(() => snode(2, memo0(() => snode(3, memo0(() => sempty))))));
let stream2 = snode(2, memo0(() => snode(3, memo0(() => snode(4, memo0(() => sempty))))));
let stream3 = snode(2, memo0(() => snode(3,memo0(() => sempty))));
let emptyStream = snode(0, memo0(() => sempty))

const infiniteStream = (n) => snode(n, memo0(()=>infiniteStream(n+1)));
const inf = infiniteStream(0);
console.log(inf.tail().tail().head());


test('factorial works', function(){
  assert(factorial(3) === 6)
  assert(factorial(4) === 24)
  assert(factorial(5) === 120)
  assert(factorial(6) === 720)
  assert(factorial(8) === 40320)
})

test('coeff works', function(){
  let coeff1 = coeff(stream, 1);
  assert(coeff1.length === 2);
  assert(coeff1[0] === 1 && coeff1[1] === 2);
  let coeff2 = coeff(stream, 2);
  assert(coeff2.length === 3)
  assert(coeff2[0] === 1 && coeff2[1] === 2 && coeff2[2] === 3)
})

test('addSeries works', function(){
  assert(addSeries(stream, stream2).tail().tail().head() === 7)
  assert(addSeries(stream, stream3).tail().tail().head() === 3)
})

test('evalSeries works', function(){
  assert(evalSeries(stream, 2)(2) === 17)
  assert(evalSeries(stream, 2)(1) === 6)
  assert(evalSeries(stream, 1)(2) === 5)
  assert(evalSeries(stream, 3)(6) === 121)
})

test('derivSeries works', function(){
  let derivatives = coeff(derivSeries(stream), 2)
  assert(derivatives[0] === 0);
  assert(derivatives[1] === 2)
  assert(derivatives[2] === 6)

})

test('rec1Series works', function(){
  let rec1Array = coeff(rec1Series(x => x+4, 0), 10)
  for(let i =0; i<rec1Array.length; ++i){
    assert(rec1Array[i] % 4 === 0)
  }
  rec1Array = coeff(rec1Series(x => x+62, 0), 10)
  for(let i =0; i<rec1Array.length; ++i){
    assert(rec1Array[i] % 62 === 0)
  }
})

test('expSeries works', function(){
  let expArray = coeff(expSeries(), 10)
  for(let i = 0; i<expArray.length; ++i){
    assert(expArray[i] === 1/factorial(i))
  }
})

test('prodSeries works', function(){
  let prodArray = coeff(prodSeries(stream, stream2), 5);
  console.log(coeff(prodSeries(stream, stream2), 5))
  assert(prodArray[0] === 2)
  assert(prodArray[1] === 7)
  assert(prodArray[2] === 16)
  assert(prodArray[3] === 17)
  assert(prodArray[4] === 12)
})

test('recurSeries works', function(){
  let init=[4,5,6,7]
  let coef = [1,2,3,4]
  let recurArr = coeff(recurSeries(coef, init), 5)
  assert(recurArr[0] === 4)
  assert(recurArr[1] === 5)
  assert(recurArr[2] === 6)
  assert(recurArr[3] === 7)
  assert(recurArr[4] === 60)
  assert(recurArr[5] === 278)
})


