// Returns a random int i where min <= i < max
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

//generateInput(n: number): number[][]
function generateInput(n){
  let prefArr = [];
  for(let i = 0; i<n; ++i){
    let arr = []
    for(let j = 0; j<n; ++j){
      let rando = randomInt(0,n);
      while(arr.includes(rando)){
        rando = randomInt(0,n)
      }
      arr.push(rando);
  }
    prefArr.push(arr)
  }
  return prefArr;
}
console.log(generateInput(3));


//oracle(f: (companies: number[][], candidates: number[][]) => Hire[]): void
function oracle(f){
  let numTests = 50; 
  let n = 10;


  for (let i = 0; i < numTests; ++i) {
    let companies = generateInput(n);
    let candidates = generateInput(n);
    let hires = f(companies, candidates);

    //Test 0 (Given Test): This test should check that the hires length is correct
    test('Hires length is correct', function() {
      assert(companies.length === hires.length);
    });


    //Test 1: This test should check that each company only got matched with only ONE candidate
    let numDup = 0;
    for(let j = 0; j< hires.length; ++j){
      let arr = hires.filter(o => hires[j].company === o.company)
      if(arr.length >1){
        numDup += 1;
      }
    }
    test('Each company only has one candidate matched', function(){
      assert(numDup === 0);
    });


    //Test 2: This test should check that each candidate has been matched with only ONE company
    numDup = 0;
    for(let j = 0; j< hires.length; ++j){
      let arr = hires.filter(o => hires[j].candidate === o.candidate)
      if(arr.length >1){
        numDup += 1;
      }
    }
    test('Each candidate only has one company matched', function(){
      assert(numDup === 0);
    });


    //Test 3: This test should check that each company got a match
    let numNoMatches = 0;
    for(let j=0; j<companies.length; ++j){
      if(!hires.some(o=> o.company === j)){
        numNoMatches += 1;
      }
    }
    test('Company was matched', function(){
      assert(numNoMatches === 0);
    });


    //Test 4: This test should check that each candidate got a match
    numNoMatches = 0;
    for(let j=0; j<candidates.length; ++j){
      if(!hires.some(o=> o.candidate === j)){
        numNoMatches += 1;
      }
    }
    test('Candidate was matched', function(){
      assert(numNoMatches === 0);
    });


    //Test 5: If a company and employee are both eachothers first choice, they should be matched together
    for(let j =0; j<companies.length; ++j){
      for(let k = 0; k<candidates.length; ++k){
        if(companies[j][0] === k && candidates[k][0] === j){
          test('Company & Candidate first pick', function(){
            assert(hires.some(o=> o.company === j && o.candidate === k))
          });
        }
      }
    }


    //Test 6: Company and candidate have some preference for each other. I made this test assuming that some company's may not rank
    // or prefer some candidates and vice versa.
    test('Company & Candidate have some preference', function(){
      assert(hires.every(o=> candidates[o.candidate].includes(o.company) && companies[o.company].includes(o.candidate)))
    });


    //Test 7: Checks if Hires is Balanced by looking at each company's preference list in the hires array. It checks all the candidate
    // that this company ranked higher then what it is paired with. Then it will check the candidates preferecne list to see if 
    // they prefer that company over their current company that they are paired with.
    let count = 0;
    for(let j=0; j<hires.length; ++j){
      let compArr = companies[hires[j].company]
      compArr = compArr.slice(0, compArr.indexOf(hires[j].candidate));
      for(let cand = 0; cand<compArr.length; ++cand){
        let candMatch = 0;
        hires.map(o =>{ if(o.candidate === compArr[cand]){ candMatch = o.company }});
        if(candidates[compArr[cand]].indexOf(hires[j].company) < candidates[compArr[cand]].indexOf(candMatch)){
          count += 1;
        }
      }
    }
    test('Hires Is Balanced', function(){
      assert(count === 0);
    })

  }
}


//The correct function with no bugs
oracle(wheat1)
//The function that has bugs
//oracle(chaff1)

//This is a function I made to test generateInput by using Property Based Testing
function testGenerateInput(){
  let numTests = 10;
  for(let i =0; i<numTests; ++i){
    let n = randomInt(0,10);
    let arr = generateInput(n)

    //This tests whether generateInput uses all values from 0-n
    test('All numbers 0-n are used', function(){
      let arrN = []
      for(let i =0; i<n; ++i){
        arrN.push(n)
      }
      let tempArrN = arrN;
      for(let i=0; i<arr.length; ++i){
        for(let j =0; j<arr[i].length; ++j){
          let num = arr[i][j];
          let numIndex = arrN.indexOf(num)
          arrN.splice(numIndex, 1);
        }
        assert(arrN.length === 0)
        arrN = tempArrN;
      }
    })
    
    //This tests whether generateInput repeats numbers in any row
    test('numbers are not repeated in any row', function(){
      let numDup = 0;
      let valuesSoFar = [];
      for(let i =0; i<arr.length; ++i){
        if(valuesSoFar.includes(arr[0][i])){ numDup +=1 }
        valuesSoFar.push(arr[0][i]);
        if(i === arr.length-1){ valuesSoFar = [] }
      }
      assert(numDup === 0);
    })

    //This tests whether generateInput returns the correct size array
    test('array is correct size', function(){
      assert(arr.length === n) // this checks that there are n arrays
      for(let j =0; j<arr.length; ++j){
        assert(arr[j].length === n) // this checks that each row has n values
      }
    })
    

  }
}
testGenerateInput()
